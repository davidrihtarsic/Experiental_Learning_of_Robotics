---
nav_exclude: true
---

# Exapmples

> pdftotext Experiential_Learning_of_Robotics.pdf
> grep "Program [0-9]" Experiential_Learning_of_Robotics.txt

Program 3.1: Hello World in ArduinoIDE.
Program 4.1: DC Motor Control with Digital Outputs.
Program 5.1: Introduction to Programming.
Program 5.2: Header file example of Robot moving functions.
Program 5.3: Programming Loops.
Program 5.4: Variables and Data Types.
Program 5.5: Conditional Statements.
Program 5.6: SRA Loop.
Program 6.1: Digital Input.
Program 6.2: Pull Up Resistors on Digital Input.
Program 6.3: PWM as Digital Input.
Program 6.4: Analog Input.
Program 6.5: Avoiding Obstacles.
Program 6.6: Ligth Sensor.
Program 6.7: Line Follower.
Program 7.1: PWM motor control.
Program 8.1: Edn of Line Detection.
